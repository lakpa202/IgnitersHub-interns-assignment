def is_palindrome(s):
    """
    Function to check whether a given string is a palindrome.
    A palindrome reads the same backward as forward.
    """
    # Normalize the string: remove non-alphanumeric characters and convert to lowercase
    cleaned = ''.join(char.lower() for char in s if char.isalnum())
    
    # Check if the cleaned string is the same as its reverse
    return cleaned == cleaned[::-1]


if __name__ == "__main__":
    input_string = input("Enter a string to check if it is a palindrome: ")
    if is_palindrome(input_string):
        print("The string is a palindrome.")
    else:
        print("The string is not a palindrome.")
