def binary_search(arr, target):
    """
    Perform binary search on a sorted array to find the target element.
    
    Parameters:
    arr (list): The sorted array.
    target: The element to search for.

    Returns:
    int: The index of the target element if found, or -1 if not found.
    """
    left, right = 0, len(arr) - 1

    while left <= right:
        mid = (left + right) // 2

        if arr[mid] == target:
            return mid
        elif arr[mid] < target:
            left = mid + 1
        else:
            right = mid - 1

    return -1


if __name__ == "__main__":
    print("Binary Search Program")
    

    array = list(map(int, input("Enter a sorted array (space-separated): ").split()))
    
   
    target = int(input("Enter the target element to search for: "))
    
    result = binary_search(array, target)
    
    if result != -1:
        print(f"Element found at index {result}.")
    else:
        print("Element not found in the array.")
