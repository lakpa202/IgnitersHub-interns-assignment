import smtplib
from email.message import EmailMessage
import mimetypes
import os

def send_email():
    # Email configuration
    sender_email = "lakpab0627@gmail.com"  
    sender_password = "xsrv yefv ywhh uudy"  
    receiver_email = "hr@ignitershub.com"

    # Subject and body
    subject = "Challenge 3 Completed"
    body = """\
Hello HR Team,

My details are as follows:
Name: Lakpa Bhutia
Semester: III
Branch: Information Technology
Roll Number: 23STPCSKGQ02012

Thank you!
"""

    # Create email message
    msg = EmailMessage()
    msg["From"] = sender_email
    msg["To"] = receiver_email
    msg["Subject"] = subject
    msg.set_content(body)

    # Image attachment
    image_path = "splash.jpg"  
    if os.path.isfile(image_path):  
        mime_type, _ = mimetypes.guess_type(image_path)
        mime_main, mime_sub = mime_type.split("/")
        with open(image_path, "rb") as img_file:
            msg.add_attachment(img_file.read(), maintype=mime_main, subtype=mime_sub, filename=os.path.basename(image_path))
    else:
        print(f"Error: Image file '{image_path}' not found.")
        return

    # Send the email
    try:
        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:  
            server.login(sender_email, sender_password)
            server.send_message(msg)
        print("Email sent successfully.")
    except smtplib.SMTPException as e:
        print(f"Error: Unable to send email. {e}")

# Call the function
if __name__ == "__main__":
    send_email()
